package com.java.darestore.darestoremsgclother;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DarestoreMsgClotherApplication {

	public static void main(String[] args) {
		SpringApplication.run(DarestoreMsgClotherApplication.class, args);
	}
}
